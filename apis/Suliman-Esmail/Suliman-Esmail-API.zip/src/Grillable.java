/**
 * A java interface class to use the grill method
 * @author Suliman Esmail
 * @since 6/13/2022
 * @version 0.1
 *
 */
public interface Grillable {
    public void grill();
}


