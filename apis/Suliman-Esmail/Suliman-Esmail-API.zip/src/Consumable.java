/**
 * A java interface class to use the consume method
 * @author Suliman Esmail
 * @since 6/13/2022
 * @version 0.1
 *
 */

public interface Consumable {
    public void consume();
}
