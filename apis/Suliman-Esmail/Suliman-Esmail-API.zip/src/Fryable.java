/**
 * A java interface class to use the fry method
 * @author Suliman Esmail
 * @since 6/13/2022
 * @version 0.1
 *
 */

public interface Fryable {
    public void fry();
}
