
public interface MarketValue {
	public int rndmMktValue();
}
