
public interface CarryWeight {
	public void setWeight(double weight);
	public double getWeight();
}
