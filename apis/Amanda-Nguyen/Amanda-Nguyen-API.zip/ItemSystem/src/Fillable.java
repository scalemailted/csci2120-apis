package src;

public interface Fillable {
    public void fill();
}
