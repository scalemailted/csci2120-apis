package src;

public interface Consumable {
    public void consume();
}
