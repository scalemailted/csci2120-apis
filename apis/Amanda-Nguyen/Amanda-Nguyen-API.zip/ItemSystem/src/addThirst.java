package src;

public interface addThirst {
    //drinking water or juices will add 1 point of thirst. each point of thirst
    //will increase player's swiftness.
    public void hydrate();
}
