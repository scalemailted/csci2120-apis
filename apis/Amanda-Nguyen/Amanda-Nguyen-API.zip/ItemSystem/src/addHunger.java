package src;

public interface addHunger {
    //food items will add to hunger, each 1 point of hunger gives attack damage buff.
    public void addHunger();
}

