package src;

public interface Stackable {
    public void stack(Stackable s);
}
