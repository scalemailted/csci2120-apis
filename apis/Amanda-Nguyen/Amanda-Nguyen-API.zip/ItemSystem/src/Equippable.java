package src;

public interface Equippable {
    public void equip();



}
