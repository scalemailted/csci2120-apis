package src;

public interface Breakable {
    public void destroy();
}
