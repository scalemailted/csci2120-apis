public interface Breakable {
    /**
     * interface will give object the quality of breaking
     */
    public void destroy();
}
