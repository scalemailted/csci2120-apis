public interface Stackable {
    /**
     *
     * @param s stacks items
     */
    public void stack (Stackable s);
}
