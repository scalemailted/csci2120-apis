import static org.junit.jupiter.api.Assertions.*;

class SwordTest {

    @org.junit.jupiter.api.Test
    void destroy() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }
}