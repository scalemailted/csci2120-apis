public interface Consumable {
    /**
     * interface will give object the quality of being consumed
     */
    public void consume();
}
