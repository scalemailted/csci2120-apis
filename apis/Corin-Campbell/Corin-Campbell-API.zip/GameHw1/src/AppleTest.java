import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AppleTest {

    @Test
    void consume() {
    }

    @Test
    void testToString() {
    }

    @Test
    void destroy() {
    }
}