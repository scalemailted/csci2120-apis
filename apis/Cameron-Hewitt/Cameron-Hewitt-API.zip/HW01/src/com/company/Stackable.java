package com.company;

public interface Stackable {
    public void stack (Stackable s);
}
