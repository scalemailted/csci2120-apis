package com.company;

public interface Readable {
    public void read();
}
