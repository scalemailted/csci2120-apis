package com.company;

public interface Learnable {
    public void taught();
}
