package main.slots;
/**
 @author Stephen Mouch
 @version 0.1
 */
/**
 * Interface for armor items belonging to the head slot.
 */
public interface Head {}
