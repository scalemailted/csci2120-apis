package org.rpg.interfaces;

/**
 * Interface for org.rpg.items.Player
 */
public interface Movable {

    /**
     * Player can move
     */
    void move();
}
