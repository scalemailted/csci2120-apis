import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WeaponTester {

    @Test
    void getDamage() {
    }

    @Test
    void getAttackPower() {
    }

    @Test
    void getWeaponHealth() {
    }

    @Test
    void setDamage() {
    }

    @Test
    void consume() {
    }

    @Test
    void destroy() {
    }

    @Test
    void testToString() {
    }
}