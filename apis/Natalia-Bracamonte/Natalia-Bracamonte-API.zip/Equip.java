/**
 * Our Equip interface holds our equip method
 */
public interface Equip{
    void equip();
}