/**
 * Our consumable interface holds our Consume method
 */
public interface Consumable{
    public void consume();
}