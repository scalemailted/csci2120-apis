/**
 * Our Stackable interface has our Stack and s Stackable
 */
public interface Stackable{
    public void stack (Stackable s);
}