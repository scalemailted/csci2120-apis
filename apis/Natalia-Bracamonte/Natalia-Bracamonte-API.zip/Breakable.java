/**
 * Our Breakable interface holds our destroy method
 */
public interface Breakable{
    public void destroy();
}