import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RangedWeaponTester {

    @Test
    void getDamage() {
    }

    @Test
    void getWeaponHealth() {
    }

    @Test
    void setDamage() {
    }

    @Test
    void consume() {
    }

    @Test
    void destroy() {
    }
}