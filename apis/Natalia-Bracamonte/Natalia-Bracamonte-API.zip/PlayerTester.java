import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTester {

    @Test
    void getPlayerName() {
    }

    @Test
    void setPlayerName() {
    }

    @Test
    void getPlayerLevel() {
    }

    @Test
    void setPlayerLevel() {
    }

    @Test
    void getPlayerWeapon() {
    }

    @Test
    void setPlayerWeapon() {
    }
}