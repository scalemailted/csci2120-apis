public interface Lose {
    /**
     * Called when the player loses.
     */
    void lose();
}
