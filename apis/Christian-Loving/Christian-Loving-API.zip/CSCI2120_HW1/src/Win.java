public interface Win {
    /**
     * Called when the player wins.
     */
    void win();
}
