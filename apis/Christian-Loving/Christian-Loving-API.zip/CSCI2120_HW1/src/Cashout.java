public interface Cashout {
    /**
     *
     * @param c
     */
    void cashOut(Cashout c);
}
