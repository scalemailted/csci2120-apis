public interface Buyin {
    /**
     *
     * @param b
     */
    void buyChips(Buyin b);
}